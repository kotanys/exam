data: list[tuple[int, int]] = []
with open("C:\\Users\\36\\Desktop\\ЕГЭ\\Вариант 8\\inf_26_04_21_27b.txt") as f:
#with open("27t.txt") as f:
    f.readline()
    for line in f:
        spl = tuple(map(int, line.split()))
        if spl[1] % 2 == 0:
            continue
        data.append(spl)

mxs, mns = list(map(lambda x: max(x), data)), list(map(lambda x: min(x), data))
mxsum = sum(mxs)
mnsum = sum(mns)
print(mxsum, mnsum)


if mxsum % 2 == 0 and mnsum % 2 != 0:
    print(mxsum + mnsum)
    exit()

mxafter = 0
for i in range(len(data)):
    if (mxsum - mxs[i]) % 2 == 0 and (mnsum - mns[i]) % 2 != 0:
        if mxsum - mxs[i] + mnsum - mns[i] > mxafter:
            mxafter = mxsum - mxs[i] + mnsum - mns[i]
            print(data[i])
print(mxafter)

# a = 61771
# b = 300868311

